import com.android.build.gradle.internal.dsl.BaseAppModuleExtension

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.7.2")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.25")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }

    apply(plugin = "com.android.application")
    apply(plugin = "kotlin-android")

    plugins.withId("com.android.application") {
        extensions.configure<BaseAppModuleExtension> {
            namespace = "com.kakao.talk.theme.apeach"

            compileSdk = 35
            buildToolsVersion = "35.0.0"

            defaultConfig {
                minSdk = 28
                targetSdk = 35

                versionName = "1.0.0"
                versionCode = project.findProperty("versionCode")?.toString()?.toInt()
                    ?: throw GradleException("versionCode property is required")
                applicationId = project.findProperty("androidApplicationId")?.toString() 
                    ?: "com.kakao.talk.theme.template"

                sourceSets {
                    getByName("main") {
                        res.srcDirs("src/main/theme", "src/main/theme-adv")
                    }
                }
            }

            compileOptions {
                sourceCompatibility = JavaVersion.VERSION_21
                targetCompatibility = JavaVersion.VERSION_21
            }

            buildFeatures {
                viewBinding = true
            }

            dependencies.add("implementation", "org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.9.25")
            dependencies.add("implementation", "androidx.annotation:annotation:1.9.1")

            signingConfigs {
                create("release") {
                    storeFile = file("/secrets/release.jks")
                    storePassword = System.getenv("KEYSTORE_PASSWORD")
                    keyAlias = System.getenv("KEY_ALIAS")
                    keyPassword = System.getenv("KEY_PASSWORD")
                }
            }

            buildTypes {
                release {
                    isMinifyEnabled = false
                    signingConfig = signingConfigs.getByName("release")
                }
            }
        }
    }
}